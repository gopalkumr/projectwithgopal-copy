﻿using Microsoft.Owin;
using Owin;
using System;
using System.Threading.Tasks;

[assembly: OwinStartup(typeof(projectwithgopal.App_Start.StartupAuth))]

namespace projectwithgopal.App_Start
{
    public class StartupAuth
    {
        public void Configuration(IAppBuilder app)
        {
            // For more information on how to configure your application, visit https://go.microsoft.com/fwlink/?LinkID=316888


        }
    }
}
